EV DEALERSHIP LANDING PAGE — INSTALLATION

1. Extract the ZIP.
2. Upload index.html and the assets folder together to Hostinger public_html or any static hosting.
3. Open your domain to view the page.

Everything interactive is in index.html (HTML + CSS + JavaScript).
Illustrations are included as local SVG files in assets; no photo downloads required.

ENQUIRY FORM
The form validates basic details then opens WhatsApp with a pre-filled message. It does not automatically send the message, save enquiries to a database, or send email.

CONTACT
Phone: +91 80511 02170
Address: Ather Energy Limited, Bannerghatta Main Road, Bangalore, Karnataka - 560029, India
These details were present in the earlier working draft and have NOT been independently verified against the live reference site.

IMPORTANT
This is an independent demo, not an official Ather Energy dealership portal. Do not represent the site as brand-authorized or collect dealership fees without appropriate permission.

TO CUSTOMIZE
Change text/phone/address in index.html. For form WhatsApp destination, change const contactPhone in the script section.
